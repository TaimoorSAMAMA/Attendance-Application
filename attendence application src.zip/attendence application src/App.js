import "./App.css";
import LoginPage from "./LoginPage";

function App() {
  return (
    <div>
      {/* <RegistrationForm /> */}
      <LoginPage />
      {/* <Dashboard /> */}
    </div>
  );
}

export default App;
