import React, { useState } from "react";
import "./App.css";
import LoginForm from "./LoginPage"; // Import the LoginForm component

function RegistrationForm() {
  const [formData, setFormData] = useState({
    username: "",
    email: "",
    password: "",
    confirmPassword: "",
  });
  const [registered, setRegistered] = useState(false);
  const [showLogin, setShowLogin] = useState(false); // State to toggle between registration and login forms
  const [loggedIn, setLoggedIn] = useState(false); // State to track if user is logged in

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleSubmit = () => {
    const { password, confirmPassword } = formData;
    // Validate password match
    if (password !== confirmPassword) {
      alert("Passwords do not match!");
      return;
    }

    // Store registered user's information in localStorage
    localStorage.setItem("registeredUser", JSON.stringify(formData));

    // Set registered to true after successful registration
    setRegistered(true);
  };

  const handleLogin = (e) => {
    e.preventDefault();
    // Handle login logic here
    // For demonstration purposes, let's consider the user is logged in after clicking login button
    setLoggedIn(true);
  };

  const handleToggleForm = () => {
    setShowLogin(!showLogin); // Toggle the state to switch between registration and login forms
  };

  if (loggedIn) {
    // Render the dashboard if the user is logged in
    return <div className="dashboard"></div>;
  }

  if (showLogin) {
    // Render LoginForm component if showLogin is true
    return (
      <LoginForm
        handleLogin={handleLogin}
        handleChange={handleChange}
        formData={formData}
      />
    );
  }

  if (registered) {
    // Render registration success message after successful registration
    return (
      <div className="registration-success">
        <h2>Registration Successful!</h2>
        <p>You can now login with your credentials.</p>
        <button className="toggle-form" onClick={handleToggleForm}>
          Login
        </button>
      </div>
    );
  }

  // Render registration form by default
  return (
    <div className="registration-container">
      <h2>Registration</h2>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          handleSubmit();
        }}
      >
        <div className="form-group">
          <label htmlFor="username">Username:</label>
          <input
            type="text"
            id="username"
            name="username"
            value={formData.username}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="email">Email:</label>
          <input
            type="email"
            id="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="password">Password:</label>
          <input
            type="password"
            id="password"
            name="password"
            value={formData.password}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="confirmPassword">Confirm Password:</label>
          <input
            type="password"
            id="confirmPassword"
            name="confirmPassword"
            value={formData.confirmPassword}
            onChange={handleChange}
            required
          />
        </div>
        <button type="submit">Register</button>
      </form>
      <span>Already have an account?</span>
      <button className="toggle-form" onClick={handleToggleForm}>
        Login
      </button>
    </div>
  );
}

export default RegistrationForm;
