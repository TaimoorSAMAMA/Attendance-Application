import React from "react";

function AdminPanel({
  attendanceRecords,
  leaveRecords,
  onApproveAttendance,
  onRejectAttendance,
  onApproveLeave,
  onRejectLeave,
}) {
  const pendingAttendance = attendanceRecords.filter(
    (record) => record.status === "pending"
  );
  const pendingLeaves = leaveRecords.filter(
    (record) => record.status === "pending"
  );

  return (
    <div className="admin-panel">
      <h2>Admin Panel</h2>
      <div className="pending-attendance">
        <h3>Pending Attendance Requests</h3>
        {pendingAttendance.length === 0 ? (
          <p>No pending attendance requests.</p>
        ) : (
          <ul>
            {pendingAttendance.map((record, index) => (
              <li key={index}>
                Date: {record.date}, Status: {record.statusDetail}
                <button onClick={() => onApproveAttendance(index)}>
                  Approve
                </button>
                <button onClick={() => onRejectAttendance(index)}>
                  Reject
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>
      <div className="pending-leaves">
        <h3>Pending Leave Requests</h3>
        {pendingLeaves.length === 0 ? (
          <p>No pending leave requests.</p>
        ) : (
          <ul>
            {pendingLeaves.map((leave, index) => (
              <li key={index}>
                From: {leave.fromDate}, To: {leave.toDate}, Reason:{" "}
                {leave.reason}
                <button onClick={() => onApproveLeave(index)}>Approve</button>
                <button onClick={() => onRejectLeave(index)}>Reject</button>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}

export default AdminPanel;

////////////////////////////////////////////////////////////////////////
// import React from "react";

// function AdminPanel({
//   attendanceRecords,
//   leaveRecords,
//   onApproveAttendance,
//   onRejectAttendance,
//   onApproveLeave,
//   onRejectLeave,
// }) {
//   const pendingAttendance = attendanceRecords.filter(
//     (record) => record.status === "pending"
//   );
//   const pendingLeaves = leaveRecords.filter(
//     (record) => record.status === "pending"
//   );

//   return (
//     <div className="admin-panel">
//       <h2>Admin Panel</h2>
//       <div className="pending-attendance">
//         <h3>Pending Attendance Requests</h3>
//         {pendingAttendance.length === 0 ? (
//           <p>No pending attendance requests.</p>
//         ) : (
//           <ul>
//             {pendingAttendance.map((record, index) => (
//               <li key={index}>
//                 Date: {record.date}, Status: {record.statusDetail}
//                 <button onClick={() => onApproveAttendance(index)}>
//                   Approve
//                 </button>
//                 <button onClick={() => onRejectAttendance(index)}>
//                   Reject
//                 </button>
//               </li>
//             ))}
//           </ul>
//         )}
//       </div>
//       <div className="pending-leaves">
//         <h3>Pending Leave Requests</h3>
//         {pendingLeaves.length === 0 ? (
//           <p>No pending leave requests.</p>
//         ) : (
//           <ul>
//             {pendingLeaves.map((leave, index) => (
//               <li key={index}>
//                 From: {leave.fromDate}, To: {leave.toDate}, Reason:{" "}
//                 {leave.reason}
//                 <button onClick={() => onApproveLeave(index)}>Approve</button>
//                 <button onClick={() => onRejectLeave(index)}>Reject</button>
//               </li>
//             ))}
//           </ul>
//         )}
//       </div>
//     </div>
//   );
// }

// export default AdminPanel;

//////////////////////////////////////////////////////////////////////////////////////////////
// import React from "react";
// import "./AdminLogin.css";

// function AdminLogin({ onLogout }) {
//   return (
//     <div className="admin-login-container">
//       <div className="admin-main-content">
//         <h1>Welcome Admin!</h1>
//         {/* Add admin-specific content here */}
//       </div>
//       <div className="admin-left-sidebar">
//         <h2>Admin Panel</h2>
//         {/* Add admin-specific buttons here */}
//         <button onClick={onLogout}>Logout</button>
//       </div>
//     </div>
//   );
// }

// export default AdminLogin;
