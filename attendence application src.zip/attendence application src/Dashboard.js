import React, { useRef, useState } from "react";
import AdminPanel from "./AdminPanel"; // Make sure to import the AdminPanel component
import HomeContent from "./HomeContent"; // Adjust the path as necessary
import AttendanceCard from "./AttendanceCard"; // Adjust the path as necessary
import LeaveCard from "./LeaveCard"; // Adjust the path as necessary
import ViewAttendance from "./ViewAttendance.js"; // Adjust the path as necessary
// E:\Courses\Projects\Attendence app\attendenceapplication\src\AdminPanel.js
function Dashboard({ username, onLogout }) {
  const [currentPage, setCurrentPage] = useState("home");
  const [attendanceRecords, setAttendanceRecords] = useState([]);
  const [leaveRecords, setLeaveRecords] = useState([]);
  const fileInputRef = useRef(null);

  const handleFileInputChange = () => {
    const file = fileInputRef.current.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        const profilePic = document.getElementById("profilePicPreview");
        profilePic.src = reader.result;
        profilePic.style.display = "block";
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAttendanceMarked = (newRecord) => {
    newRecord.status = "pending";
    setAttendanceRecords([...attendanceRecords, newRecord]);
    setCurrentPage("home");
  };

  const handleLeaveSubmit = (leaveData) => {
    leaveData.status = "pending";
    setLeaveRecords([...leaveRecords, leaveData]);
    setCurrentPage("home");
  };

  const toggleView = (pageName) => {
    setCurrentPage(pageName);
  };

  // Approval and Rejection Functions
  const handleApproveAttendance = (index) => {
    const updatedRecords = [...attendanceRecords];
    updatedRecords[index].status = "approved";
    setAttendanceRecords(updatedRecords);
  };

  const handleRejectAttendance = (index) => {
    const updatedRecords = [...attendanceRecords];
    updatedRecords[index].status = "rejected";
    setAttendanceRecords(updatedRecords);
  };

  const handleApproveLeave = (index) => {
    const updatedRecords = [...leaveRecords];
    updatedRecords[index].status = "approved";
    setLeaveRecords(updatedRecords);
  };

  const handleRejectLeave = (index) => {
    const updatedRecords = [...leaveRecords];
    updatedRecords[index].status = "rejected";
    setLeaveRecords(updatedRecords);
  };

  return (
    <div className="app">
      <div className="left-sidebar">
        <h2>Menu</h2>
        <div id="userPanel">
          <h3>User Panel</h3>
          <button onClick={() => setCurrentPage("home")}>Home</button>
          <button onClick={() => toggleView("markAttendance")}>
            Mark Attendance
          </button>
          <button onClick={() => toggleView("markLeave")}>Mark Leave</button>
          <button onClick={() => toggleView("viewAttendance")}>
            View Attendance
          </button>
          <button onClick={() => setCurrentPage("editProfile")}>
            Edit Profile
          </button>
          <br />
          <label htmlFor="profilePic" className="file-upload-button">
            Upload Profile Pic
          </label>
          <input
            type="file"
            id="profilePic"
            accept="image/*"
            ref={fileInputRef}
            onChange={handleFileInputChange}
            style={{ display: "none" }}
          />
        </div>
        <div id="adminPanel" className="adminPanelview">
          <AdminPanel
            attendanceRecords={attendanceRecords}
            leaveRecords={leaveRecords}
            onApproveAttendance={handleApproveAttendance}
            onRejectAttendance={handleRejectAttendance}
            onApproveLeave={handleApproveLeave}
            onRejectLeave={handleRejectLeave}
          />
        </div>
      </div>
      <div className="main-content">
        <h1>Attendance Management System</h1>
        {currentPage === "home" && (
          <HomeContent
            username={username}
            leaveRecords={leaveRecords}
            attendanceRecords={attendanceRecords}
            onToggleView={toggleView}
            currentPage={currentPage}
          />
        )}

        {currentPage === "markAttendance" && (
          <AttendanceCard
            onAttendanceMarked={handleAttendanceMarked}
            leaveRecords={leaveRecords}
          />
        )}

        {currentPage === "markLeave" && (
          <LeaveCard onLeaveSubmit={handleLeaveSubmit} />
        )}

        {currentPage === "viewAttendance" && (
          <ViewAttendance
            attendanceRecords={attendanceRecords}
            leaveRecords={leaveRecords}
          />
        )}
        <img
          className="imgview"
          id="profilePicPreview"
          alt="Profile Pic Preview"
        />
      </div>
      <button className="logout-button" onClick={onLogout}>
        Logout
      </button>
    </div>
  );
}

//////////////////////////////////////////////////////////////////////////
// import React, { useRef, useState } from "react";

// function Dashboard({ username, onLogout }) {
//   const [currentPage, setCurrentPage] = useState("home");
//   const [attendanceRecords, setAttendanceRecords] = useState([]);
//   const [leaveRecords, setLeaveRecords] = useState([]);
//   const fileInputRef = useRef(null);

//   const handleFileInputChange = () => {
//     const file = fileInputRef.current.files[0];
//     if (file) {
//       const reader = new FileReader();
//       reader.onload = () => {
//         const profilePic = document.getElementById("profilePicPreview");
//         profilePic.src = reader.result;
//         profilePic.style.display = "block";
//       };
//       reader.readAsDataURL(file);
//     }
//   };

//   const handleAttendanceMarked = (newRecord) => {
//     newRecord.status = "pending";
//     setAttendanceRecords([...attendanceRecords, newRecord]);
//     setCurrentPage("home");
//   };

//   const handleLeaveSubmit = (leaveData) => {
//     leaveData.status = "pending";
//     setLeaveRecords([...leaveRecords, leaveData]);
//     setCurrentPage("home");
//   };

//   const toggleView = (pageName) => {
//     setCurrentPage(pageName);
//   };

//   return (
//     <div className="app">
//       <div className="left-sidebar">
//         <h2>Menu</h2>
//         <div id="userPanel">
//           <h3>User Panel</h3>
//           <button onClick={() => setCurrentPage("home")}>Home</button>
//           <button onClick={() => toggleView("markAttendance")}>
//             Mark Attendance
//           </button>
//           <button onClick={() => toggleView("markLeave")}>Mark Leave</button>
//           <button onClick={() => toggleView("viewAttendance")}>
//             View Attendance
//           </button>
//           <button onClick={() => setCurrentPage("editProfile")}>
//             Edit Profile
//           </button>
//           <br />
//           <label htmlFor="profilePic" className="file-upload-button">
//             Upload Profile Pic
//           </label>
//           <input
//             type="file"
//             id="profilePic"
//             accept="image/*"
//             ref={fileInputRef}
//             onChange={handleFileInputChange}
//             style={{ display: "none" }}
//           />
//         </div>
//         <div id="adminPanel" className="adminPanelview"></div>
//       </div>
//       <div className="main-content">
//         <h1>Attendance Management System</h1>
//         {currentPage === "home" && (
//           <HomeContent
//             username={username}
//             leaveRecords={leaveRecords}
//             attendanceRecords={attendanceRecords}
//             onToggleView={toggleView}
//             currentPage={currentPage}
//           />
//         )}

//         {currentPage === "markAttendance" && (
//           <AttendanceCard
//             onAttendanceMarked={handleAttendanceMarked}
//             leaveRecords={leaveRecords}
//           />
//         )}

//         {currentPage === "markLeave" && (
//           <LeaveCard onLeaveSubmit={handleLeaveSubmit} />
//         )}

//         {currentPage === "viewAttendance" && (
//           <ViewAttendance
//             attendanceRecords={attendanceRecords}
//             leaveRecords={leaveRecords}
//           />
//         )}
//         <img
//           className="imgview"
//           id="profilePicPreview"
//           alt="Profile Pic Preview"
//         />
//       </div>
//       <button className="logout-button" onClick={onLogout}>
//         Logout
//       </button>
//     </div>
//   );
// }

// function HomeContent({
//   username,
//   leaveRecords,
//   attendanceRecords,
//   onToggleView,
//   currentPage,
// }) {
//   const showLeaveDates = currentPage === "home" && leaveRecords.length > 0;
//   const showAttendanceRecords =
//     currentPage === "home" && attendanceRecords.length > 0;

//   return (
//     <div>
//       <div className="card">
//         <h3>Welcome, {username}!</h3>
//         <p>This is some random information.</p>
//       </div>
//       {showLeaveDates && (
//         <div className="card">
//           <h3>Leave Dates</h3>
//           <ul style={{ listStyle: "none", padding: 0 }}>
//             {leaveRecords.map((record, index) => (
//               <li key={index}>
//                 {record.fromDate && `From: ${record.fromDate}, `}
//                 {record.toDate && `To: ${record.toDate}, `}
//                 {record.reason && `Reason: ${record.reason}, `}
//                 {record.status && `Status: ${record.status}`}
//               </li>
//             ))}
//           </ul>
//         </div>
//       )}
//       {showAttendanceRecords && (
//         <div className="card">
//           <h3>Attendance Records</h3>
//           <ul>
//             {attendanceRecords.map((record, index) => (
//               <li key={index}>
//                 Date: {record.date}, Status: {record.status},{" "}
//                 {record.statusDetail}
//               </li>
//             ))}
//           </ul>
//         </div>
//       )}
//     </div>
//   );
// }
// function AttendanceCard({ onAttendanceMarked, leaveRecords }) {
//   const [selectedDate, setSelectedDate] = useState("");
//   const [attendanceStatus, setAttendanceStatus] = useState("");
//   const [markedDates, setMarkedDates] = useState([]);

//   const handleDateChange = (event) => {
//     setSelectedDate(event.target.value);
//   };

//   const handleAttendanceSubmit = (event) => {
//     event.preventDefault();

//     if (markedDates.includes(selectedDate)) {
//       alert("Attendance for this date is already marked.");
//       return;
//     }

//     const leaveDay = leaveRecords.some(
//       (leave) =>
//         new Date(selectedDate) >= new Date(leave.fromDate) &&
//         new Date(selectedDate) <= new Date(leave.toDate)
//     );
//     if (leaveDay) {
//       alert("You are on leave on this day.");
//       return;
//     }

//     const newRecord = {
//       date: selectedDate,
//       status: "pending",
//       statusDetail: attendanceStatus,
//     };
//     onAttendanceMarked(newRecord);
//     setMarkedDates([...markedDates, selectedDate]);
//     setSelectedDate("");
//     setAttendanceStatus("");
//   };

//   return (
//     <div className="card">
//       <h3>Mark Attendance</h3>
//       <form onSubmit={handleAttendanceSubmit}>
//         <div className="form-group">
//           <label htmlFor="attendanceDate">Select Date:</label>
//           <input
//             type="date"
//             id="attendanceDate"
//             value={selectedDate}
//             onChange={handleDateChange}
//             required
//           />
//         </div>
//         <div className="form-group">
//           <label htmlFor="attendanceStatus">Select Status:</label>
//           <select
//             id="attendanceStatus"
//             value={attendanceStatus}
//             onChange={(e) => setAttendanceStatus(e.target.value)}
//             required
//           >
//             <option value="">Select Status</option>
//             <option value="present">Present</option>
//             <option value="absent">Absent</option>
//           </select>
//         </div>
//         <button type="submit">Submit Attendance</button>
//       </form>
//     </div>
//   );
// }

// function LeaveCard({ onLeaveSubmit }) {
//   const [fromDate, setFromDate] = useState("");
//   const [toDate, setToDate] = useState("");
//   const [reason, setReason] = useState("");

//   const handleLeaveSubmit = (event) => {
//     event.preventDefault();
//     const leaveData = { fromDate, toDate, reason, status: "pending" };
//     onLeaveSubmit(leaveData);
//   };

//   return (
//     <div className="card">
//       <h3>Mark Leave</h3>
//       <form onSubmit={handleLeaveSubmit}>
//         <div className="form-group">
//           <label htmlFor="fromDate">From Date:</label>
//           <input
//             type="date"
//             id="fromDate"
//             value={fromDate}
//             onChange={(e) => setFromDate(e.target.value)}
//             required
//           />
//         </div>
//         <div className="form-group">
//           <label htmlFor="toDate">To Date:</label>
//           <input
//             type="date"
//             id="toDate"
//             value={toDate}
//             onChange={(e) => setToDate(e.target.value)}
//             required
//           />
//         </div>
//         <div className="form-group">
//           <label htmlFor="reason">Reason:</label>
//           <textarea
//             id="reason"
//             value={reason}
//             onChange={(e) => setReason(e.target.value)}
//             required
//           ></textarea>
//         </div>
//         <button type="submit">Submit Leave</button>
//       </form>
//     </div>
//   );
// }

// function ViewAttendance({ attendanceRecords }) {
//   return (
//     <div className="view-attendance">
//       <div className="attendance">
//         <h3>Attendance Records</h3>
//         <ul>
//           {attendanceRecords.map((record, index) => (
//             <li key={index}>
//               Date: {record.date}, Status: {record.status},{" "}
//               {record.statusDetail}
//             </li>
//           ))}
//         </ul>
//       </div>
//     </div>
//   );
// }
// const handleApproveAttendance = (index) => {
//   const updatedRecords = [...attendanceRecords];
//   updatedRecords[index].status = "approved";
//   setAttendanceRecords(updatedRecords);
// };

// const handleRejectAttendance = (index) => {
//   const updatedRecords = [...attendanceRecords];
//   updatedRecords[index].status = "rejected";
//   setAttendanceRecords(updatedRecords);
// };

// const handleApproveLeave = (index) => {
//   const updatedRecords = [...leaveRecords];
//   updatedRecords[index].status = "approved";
//   setLeaveRecords(updatedRecords);
// };

// const handleRejectLeave = (index) => {
//   const updatedRecords = [...leaveRecords];
//   updatedRecords[index].status = "rejected";
//   setLeaveRecords(updatedRecords);
// };

// // Inside the return statement of Dashboard component
// <div id="adminPanel" className="adminPanelview">
//   <AdminPanel
//     attendanceRecords={attendanceRecords}
//     leaveRecords={leaveRecords}
//     onApproveAttendance={handleApproveAttendance}
//     onRejectAttendance={handleRejectAttendance}
//     onApproveLeave={handleApproveLeave}
//     onRejectLeave={handleRejectLeave}
//   />
// </div>;

// export default Dashboard;

////////////////////////////////////////////////////////////////////////////////////////////////
// import React, { useRef, useState } from "react";

// function Dashboard({ username, onLogout }) {
//   const [currentPage, setCurrentPage] = useState("home");
//   const [attendanceRecords, setAttendanceRecords] = useState([]);
//   const [leaveRecords, setLeaveRecords] = useState([]);
//   const fileInputRef = useRef(null);

//   const handleFileInputChange = () => {
//     const file = fileInputRef.current.files[0];
//     if (file) {
//       const reader = new FileReader();
//       reader.onload = () => {
//         const profilePic = document.getElementById("profilePicPreview");
//         profilePic.src = reader.result;
//         profilePic.style.display = "block";
//       };
//       reader.readAsDataURL(file);
//     }
//   };

//   const handleAttendanceMarked = (newRecord) => {
//     setAttendanceRecords([...attendanceRecords, newRecord]);
//     setCurrentPage("home");
//   };

//   const handleLeaveSubmit = (leaveData) => {
//     setLeaveRecords([...leaveRecords, leaveData]);
//     setCurrentPage("home");
//   };

//   const toggleView = (pageName) => {
//     setCurrentPage(pageName);
//   };

//   return (
//     <div className="app">
//       <div className="left-sidebar">
//         <h2>Menu</h2>
//         <div id="userPanel">
//           <h3>User Panel</h3>
//           <button onClick={() => setCurrentPage("home")}>Home</button>
//           <button onClick={() => toggleView("markAttendance")}>
//             Mark Attendance
//           </button>
//           <button onClick={() => toggleView("markLeave")}>Mark Leave</button>
//           <button onClick={() => toggleView("viewAttendance")}>
//             View Attendance
//           </button>
//           <button onClick={() => setCurrentPage("editProfile")}>
//             Edit Profile
//           </button>
//           <br />
//           <label htmlFor="profilePic" className="file-upload-button">
//             Upload Profile Pic
//           </label>
//           <input
//             type="file"
//             id="profilePic"
//             accept="image/*"
//             ref={fileInputRef}
//             onChange={handleFileInputChange}
//             style={{ display: "none" }}
//           />
//         </div>
//         <div id="adminPanel" className="adminPanelview"></div>
//       </div>
//       <div className="main-content">
//         <h1>Attendance Management System</h1>
//         {currentPage === "home" && (
//           <HomeContent
//             username={username}
//             leaveRecords={leaveRecords}
//             attendanceRecords={attendanceRecords}
//             onToggleView={toggleView}
//             currentPage={currentPage}
//           />
//         )}

//         {currentPage === "markAttendance" && (
//           <AttendanceCard
//             onAttendanceMarked={handleAttendanceMarked}
//             leaveRecords={leaveRecords}
//           />
//         )}

//         {currentPage === "markLeave" && (
//           <LeaveCard onLeaveSubmit={handleLeaveSubmit} />
//         )}

//         {currentPage === "viewAttendance" && (
//           <ViewAttendance
//             attendanceRecords={attendanceRecords}
//             leaveRecords={leaveRecords}
//           />
//         )}
//         <img
//           className="imgview"
//           id="profilePicPreview"
//           alt="Profile Pic Preview"
//         />
//       </div>
//       <button className="logout-button" onClick={onLogout}>
//         Logout
//       </button>
//     </div>
//   );
// }

// function HomeContent({
//   username,
//   leaveRecords,
//   attendanceRecords,
//   onToggleView,
//   currentPage,
// }) {
//   const showLeaveDates = currentPage === "home" && leaveRecords.length > 0;
//   const showAttendanceRecords =
//     currentPage === "home" && attendanceRecords.length > 0;

//   return (
//     <div>
//       <div className="card">
//         <h3>Welcome, {username}!</h3>
//         <p>This is some random information.</p>
//       </div>
//       {showLeaveDates && (
//         <div className="card">
//           <h3>Leave Dates</h3>
//           <ul style={{ listStyle: "none", padding: 0 }}>
//             {leaveRecords.map((record, index) => (
//               <li key={index}>
//                 {record.fromDate && `From: ${record.fromDate}, `}
//                 {record.toDate && `To: ${record.toDate}, `}
//                 {record.reason && `Reason: ${record.reason}`}
//               </li>
//             ))}
//           </ul>
//         </div>
//       )}
//       {showAttendanceRecords && (
//         <div className="card">
//           <h3>Attendance Records</h3>
//           <ul>
//             {attendanceRecords.map((record, index) => (
//               <li key={index}>
//                 Date: {record.date}, Status: {record.status}
//               </li>
//             ))}
//           </ul>
//         </div>
//       )}
//     </div>
//   );
// }
// function AttendanceCard({ onAttendanceMarked, leaveRecords }) {
//   const [selectedDate, setSelectedDate] = useState("");
//   const [attendanceStatus, setAttendanceStatus] = useState("");
//   const [markedDates, setMarkedDates] = useState([]);

//   const handleDateChange = (event) => {
//     setSelectedDate(event.target.value);
//   };

//   const handleAttendanceSubmit = (event) => {
//     event.preventDefault();

//     if (markedDates.includes(selectedDate)) {
//       alert("Attendance for this date is already marked.");
//       return;
//     }

//     const leaveDay = leaveRecords.some(
//       (leave) =>
//         new Date(selectedDate) >= new Date(leave.fromDate) &&
//         new Date(selectedDate) <= new Date(leave.toDate)
//     );
//     if (leaveDay) {
//       alert("You are on leave on this day.");
//       return;
//     }

//     const newRecord = { date: selectedDate, status: attendanceStatus };
//     onAttendanceMarked(newRecord);
//     setMarkedDates([...markedDates, selectedDate]);
//     setSelectedDate("");
//     setAttendanceStatus("");
//   };

//   return (
//     <div className="card">
//       <h3>Mark Attendance</h3>
//       <form onSubmit={handleAttendanceSubmit}>
//         <div className="form-group">
//           <label htmlFor="attendanceDate">Select Date:</label>
//           <input
//             type="date"
//             id="attendanceDate"
//             value={selectedDate}
//             onChange={handleDateChange}
//             required
//           />
//         </div>
//         <div className="form-group">
//           <label htmlFor="attendanceStatus">Select Status:</label>
//           <select
//             id="attendanceStatus"
//             value={attendanceStatus}
//             onChange={(e) => setAttendanceStatus(e.target.value)}
//             required
//           >
//             <option value="">Select Status</option>
//             <option value="present">Present</option>
//             <option value="absent">Absent</option>
//           </select>
//         </div>
//         <button type="submit">Submit Attendance</button>
//       </form>
//     </div>
//   );
// }

// function LeaveCard({ onLeaveSubmit }) {
//   const [fromDate, setFromDate] = useState("");
//   const [toDate, setToDate] = useState("");
//   const [reason, setReason] = useState("");

//   const handleLeaveSubmit = (event) => {
//     event.preventDefault();
//     const leaveData = { fromDate, toDate, reason };
//     onLeaveSubmit(leaveData);
//   };

//   return (
//     <div className="card">
//       <h3>Mark Leave</h3>
//       <form onSubmit={handleLeaveSubmit}>
//         <div className="form-group">
//           <label htmlFor="fromDate">From Date:</label>
//           <input
//             type="date"
//             id="fromDate"
//             value={fromDate}
//             onChange={(e) => setFromDate(e.target.value)}
//             required
//           />
//         </div>
//         <div className="form-group">
//           <label htmlFor="toDate">To Date:</label>
//           <input
//             type="date"
//             id="toDate"
//             value={toDate}
//             onChange={(e) => setToDate(e.target.value)}
//             required
//           />
//         </div>
//         <div className="form-group">
//           <label htmlFor="reason">Reason:</label>
//           <textarea
//             id="reason"
//             value={reason}
//             onChange={(e) => setReason(e.target.value)}
//             required
//           ></textarea>
//         </div>
//         <button type="submit">Submit Leave</button>
//       </form>
//     </div>
//   );
// }

// function ViewAttendance({ attendanceRecords }) {
//   return (
//     <div className="view-attendance">
//       <div className="attendance">
//         <h3>Attendance Records</h3>
//         <ul>
//           {attendanceRecords.map((record, index) => (
//             <li key={index}>
//               Date: {record.date}, Status: {record.status}
//             </li>
//           ))}
//         </ul>
//       </div>
//     </div>
//   );
// }

// export default Dashboard;
