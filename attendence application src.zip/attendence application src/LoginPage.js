import React, { useState } from "react";
import Dashboard from "./Dashboard";
import RegistrationForm from "./RegistrationForm";
import AdminLogin from "./AdminPanel";
import "./Login.css";

function LoginPage() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [loggedIn, setLoggedIn] = useState(false);
  const [showRegistration, setShowRegistration] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (username === "admin" && password === "admin" && !isAdmin) {
      setIsAdmin(true);
    } else {
      if (
        (username === "Admin" && password === "admin") ||
        (username === "admin" && password === "admin")
      ) {
        alert("Please use 'Login as Admin' button to log in as admin.");
      } else {
        setLoggedIn(true);
      }
    }
  };

  const handleLogout = () => {
    setLoggedIn(false);
    setIsAdmin(false);
    setUsername("");
    setPassword("");
  };

  const handleRegister = () => {
    setShowRegistration(true);
  };

  const handleLoginAsAdmin = () => {
    if (username === "admin" && password === "admin") {
      setLoggedIn(true);
      setIsAdmin(true);
    } else {
      alert("Incorrect username or password for admin login");
    }
  };

  return (
    <>
      {!loggedIn && !showRegistration && !isAdmin && (
        <form className="login-container" onSubmit={handleSubmit}>
          <h2>Login</h2>
          <div className="form-group">
            <label htmlFor="username">Username:</label>
            <input
              type="text"
              id="username"
              className="input-field"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              required
            />
          </div>
          <div className="form-group">
            <label htmlFor="password">Password:</label>
            <input
              type="password"
              id="password"
              className="input-field"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>
          <button
            type="submit"
            className="login-button"
            disabled={username === "admin" && password === "admin"}
          >
            Login
          </button>
          <span className="no-account">Have no account?</span>
          <button
            type="button"
            className="register-button"
            onClick={handleRegister}
          >
            Register
          </button>
          <button
            type="button"
            className="admin-login-button no-account1"
            onClick={handleLoginAsAdmin}
          >
            Login as Admin
          </button>
        </form>
      )}
      {loggedIn && !isAdmin && (
        <Dashboard username={username} onLogout={handleLogout} />
      )}
      {isAdmin && <AdminLogin onLogout={handleLogout} />}
      {showRegistration && <RegistrationForm />}
    </>
  );
}

export default LoginPage;

////////////////////////////////////////////////////////////////////////////
// import React, { useState } from "react";
// import Dashboard from "./Dashboard";
// import RegistrationForm from "./RegistrationForm";
// import AdminLogin from "./AdminLogin";
// import "./Login.css";

// function LoginPage() {
//   const [username, setUsername] = useState("");
//   const [password, setPassword] = useState("");
//   const [loggedIn, setLoggedIn] = useState(false);
//   const [showRegistration, setShowRegistration] = useState(false);
//   const [isAdmin, setIsAdmin] = useState(false);

//   const handleSubmit = (e) => {
//     e.preventDefault();
//     if (username === "admin" && password === "admin" && !isAdmin) {
//       setIsAdmin(true);
//     } else {
//       if (username === "admin" && password === "admin") {
//         alert("Please use 'Login as Admin' button to log in as admin.");
//       } else {
//         setLoggedIn(true);
//       }
//     }
//   };

//   const handleLogout = () => {
//     setLoggedIn(false);
//     setIsAdmin(false);
//     setUsername("");
//     setPassword("");
//   };

//   const handleRegister = () => {
//     setShowRegistration(true);
//   };

//   const handleLoginAsAdmin = () => {
//     if (username === "admin" && password === "admin") {
//       setLoggedIn(true);
//       setIsAdmin(true);
//     } else {
//       alert("Incorrect username or password for admin login");
//     }
//   };

//   return (
//     <>
//       {!loggedIn && !showRegistration && !isAdmin && (
//         <form className="login-container" onSubmit={handleSubmit}>
//           <h2>Login</h2>
//           <div className="form-group">
//             <label htmlFor="username">Username:</label>
//             <input
//               type="text"
//               id="username"
//               className="input-field"
//               value={username}
//               onChange={(e) => setUsername(e.target.value)}
//               required
//             />
//           </div>
//           <div className="form-group">
//             <label htmlFor="password">Password:</label>
//             <input
//               type="password"
//               id="password"
//               className="input-field"
//               value={password}
//               onChange={(e) => setPassword(e.target.value)}
//               required
//             />
//           </div>
//           <button type="submit" className="login-button">
//             Login
//           </button>
//           <span className="no-account">Have no account?</span>
//           <button
//             type="button"
//             className="register-button"
//             onClick={handleRegister}
//           >
//             Register
//           </button>
//           <button
//             type="button"
//             className="admin-login-button no-account1"
//             onClick={handleLoginAsAdmin}
//           >
//             Login as Admin
//           </button>
//         </form>
//       )}
//       {loggedIn && !isAdmin && (
//         <Dashboard username={username} onLogout={handleLogout} />
//       )}
//       {isAdmin && <AdminLogin onLogout={handleLogout} />}
//       {showRegistration && <RegistrationForm />}
//     </>
//   );
// }

// export default LoginPage;

///////////////////////////////////////////////////////////////////////////////////
// import React, { useState } from "react";
// import Dashboard from "./Dashboard";
// import RegistrationForm from "./RegistrationForm";
// import "./Login.css";

// function LoginPage() {
//   const [username, setUsername] = useState("");
//   const [password, setPassword] = useState("");
//   const [loggedIn, setLoggedIn] = useState(false);
//   const [showRegistration, setShowRegistration] = useState(false);

//   const handleSubmit = (e) => {
//     e.preventDefault();
//     if (username === "admin" && password === "admin") {
//       alert(
//         "You are trying to log in as admin. Please use 'Login as Admin' button."
//       );
//     } else {
//       setLoggedIn(true);
//     }
//   };

//   const handleLogout = () => {
//     setLoggedIn(false);
//     setUsername("");
//     setPassword("");
//   };

//   const handleRegister = () => {
//     setShowRegistration(true);
//   };

//   const handleLoginAsAdmin = () => {
//     if (username === "admin" && password === "admin") {
//       setLoggedIn(true);
//     } else {
//       alert("Incorrect username or password for admin login");
//     }
//   };

//   return (
//     <>
//       {!loggedIn && !showRegistration && (
//         <form className="login-container" onSubmit={handleSubmit}>
//           <h2>Login</h2>
//           <div className="form-group">
//             <label htmlFor="username">Username:</label>
//             <input
//               type="text"
//               id="username"
//               className="input-field"
//               value={username}
//               onChange={(e) => setUsername(e.target.value)}
//               required
//             />
//           </div>
//           <div className="form-group">
//             <label htmlFor="password">Password:</label>
//             <input
//               type="password"
//               id="password"
//               className="input-field"
//               value={password}
//               onChange={(e) => setPassword(e.target.value)}
//               required
//             />
//           </div>
//           <button type="submit" className="login-button">
//             Login
//           </button>
//           <span className="no-account">Have no account?</span>
//           <button
//             type="button"
//             className="register-button"
//             onClick={handleRegister}
//           >
//             Register
//           </button>
//           <button
//             type="button"
//             className="admin-login-button no-account1"
//             onClick={handleLoginAsAdmin}
//           >
//             Login as Admin
//           </button>
//         </form>
//       )}
//       {loggedIn && <Dashboard username={username} onLogout={handleLogout} />}
//       {showRegistration && <RegistrationForm />}
//     </>
//   );
// }

// export default LoginPage;

///////////////////////////////////////////////////////////////////////////////////////
// import React, { useState } from "react";
// import Dashboard from "./Dashboard";
// import RegistrationForm from "./RegistrationForm";
// import "./Login.css";

// function LoginPage() {
//   const [username, setUsername] = useState("");
//   const [password, setPassword] = useState("");
//   const [loggedIn, setLoggedIn] = useState(false);
//   const [showRegistration, setShowRegistration] = useState(false);

//   const handleSubmit = (e) => {
//     e.preventDefault();
//     setLoggedIn(true);
//   };

//   const handleLogout = () => {
//     setLoggedIn(false);
//     setUsername("");
//     setPassword("");
//   };

//   const handleRegister = () => {
//     setShowRegistration(true);
//   };

//   return (
//     <>
//       {!loggedIn && !showRegistration && (
//         <form className="login-container" onSubmit={handleSubmit}>
//           <h2>Login</h2>
//           <div className="form-group">
//             <label htmlFor="username">Username:</label>
//             <input
//               type="text"
//               id="username"
//               className="input-field"
//               value={username}
//               onChange={(e) => setUsername(e.target.value)}
//               required
//             />
//           </div>
//           <div className="form-group">
//             <label htmlFor="password">Password:</label>
//             <input
//               type="password"
//               id="password"
//               className="input-field"
//               value={password}
//               onChange={(e) => setPassword(e.target.value)}
//               required
//             />
//           </div>
//           <button type="submit" className="login-button">
//             Login
//           </button>
//           <span className="no-account">Have no account?</span>
//           <button
//             type="button"
//             className="register-button"
//             onClick={handleRegister}
//           >
//             Register
//           </button>
//           <button className="no-account1">Login as admin</button>
//         </form>
//       )}
//       {loggedIn && <Dashboard username={username} onLogout={handleLogout} />}
//       {showRegistration && <RegistrationForm />}
//     </>
//   );
// }

// export default LoginPage;

/////////////////////////////////////////////////////////////////////////////////////
// import React, { useState } from "react";
// import Dashboard from "./Dashboard"; // Assuming Dashboard.js is in the same directory
// import RegistrationForm from "./RegistrationForm"; // Assuming RegistrationForm.js is in the same directory
// import "./Login.css";

// function LoginPage() {
//   const [username, setUsername] = useState("");
//   const [password, setPassword] = useState("");
//   const [loggedIn, setLoggedIn] = useState(false);
//   const [showRegistration, setShowRegistration] = useState(false);

//   const handleSubmit = (e) => {
//     e.preventDefault();
//     setLoggedIn(true);
//   };

//   const handleLogout = () => {
//     setLoggedIn(false);
//     setUsername("");
//     setPassword("");
//   };

//   const handleRegister = () => {
//     setShowRegistration(true); // Show the registration form
//   };

//   return (
//     <>
//       {!loggedIn && !showRegistration && (
//         <form className="login-container" onSubmit={handleSubmit}>
//           <h2>Login</h2>
//           <div className="form-group">
//             <label htmlFor="username">Username:</label>
//             <input
//               type="text"
//               id="username"
//               className="input-field"
//               value={username}
//               onChange={(e) => setUsername(e.target.value)}
//               required
//             />
//           </div>
//           <div className="form-group">
//             <label htmlFor="password">Password:</label>
//             <input
//               type="password"
//               id="password"
//               className="input-field"
//               value={password}
//               onChange={(e) => setPassword(e.target.value)}
//               required
//             />
//           </div>
//           <button type="submit" className="login-button">
//             Login
//           </button>
//           <span className="no-account">Have no account?</span>
//           <button
//             type="button"
//             className="register-button"
//             onClick={handleRegister}
//           >
//             Register
//           </button>
//         </form>
//       )}
//       {loggedIn && <Dashboard />}
//       {showRegistration && <RegistrationForm />}
//       {loggedIn && (
//         <button className="logout-button" onClick={handleLogout}>
//           Logout
//         </button>
//       )}
//     </>
//   );
// }

// export default LoginPage;

///////////////////////////////////////////////////////////////////////////////
// import React, { useState } from "react";
// import Dashboard from "./Dashboard"; // Assuming Dashboard.js is in the same directory
// import RegistrationForm from "./RegistrationForm"; // Assuming RegistrationForm.js is in the same directory
// import "./Login.css";

// function LoginPage() {
//   const [username, setUsername] = useState("");
//   const [password, setPassword] = useState("");
//   const [loggedIn, setLoggedIn] = useState(false);
//   const [showRegistration, setShowRegistration] = useState(false);

//   const handleSubmit = (e) => {
//     e.preventDefault();
//     setLoggedIn(true);
//   };

//   const handleLogout = () => {
//     setLoggedIn(false);
//     setUsername("");
//     setPassword("");
//   };

//   const handleRegister = () => {
//     setShowRegistration(true); // Show the registration form
//   };

//   return (
//     <>
//       {loggedIn ? (
//         <Dashboard />
//       ) : (
//         <>
//           <form className="login-container" onSubmit={handleSubmit}>
//             <h2>Login</h2>
//             <div className="form-group">
//               <label htmlFor="username">Username:</label>
//               <input
//                 type="text"
//                 id="username"
//                 className="input-field"
//                 value={username}
//                 onChange={(e) => setUsername(e.target.value)}
//                 required
//               />
//             </div>
//             <div className="form-group">
//               <label htmlFor="password">Password:</label>
//               <input
//                 type="password"
//                 id="password"
//                 className="input-field"
//                 value={password}
//                 onChange={(e) => setPassword(e.target.value)}
//                 required
//               />
//             </div>
//             <button type="submit" className="login-button">
//               Login
//             </button>
//             <span className="no-account">Have no account?</span>
//             <button
//               type="button"
//               className="register-button"
//               onClick={handleRegister}
//             >
//               Register
//             </button>
//           </form>
//           {showRegistration && <RegistrationForm />}
//         </>
//       )}
//       {loggedIn && (
//         <button className="logout-button" onClick={handleLogout}>
//           Logout
//         </button>
//       )}
//     </>
//   );
// }

// export default LoginPage;

/////////////////////////////////////////////////////////////////////////////////////
// import React, { useState } from "react";
// import Dashboard from "./Dashboard"; // Assuming Dashboard.js is in the same directory
// import RegistrationForm from "./RegistrationForm"; // Assuming RegistrationForm.js is in the same directory
// import "./Login.css";

// function LoginPage() {
//   const [username, setUsername] = useState("");
//   const [password, setPassword] = useState("");
//   const [loggedIn, setLoggedIn] = useState(false);
//   const [showRegistration, setShowRegistration] = useState(false);

//   const handleSubmit = (e) => {
//     e.preventDefault();
//     setLoggedIn(true);
//   };

//   const handleLogout = () => {
//     setLoggedIn(false);
//     setUsername("");
//     setPassword("");
//   };

//   const handleRegister = () => {
//     setShowRegistration(true); // Show the registration form
//   };

//   return (
//     <>
//       {loggedIn ? (
//         <Dashboard />
//       ) : (
//         <form className="login-container" onSubmit={handleSubmit}>
//           <h2>Login</h2>
//           <div className="form-group">
//             <label htmlFor="username">Username:</label>
//             <input
//               type="text"
//               id="username"
//               className="input-field"
//               value={username}
//               onChange={(e) => setUsername(e.target.value)}
//               required
//             />
//           </div>
//           <div className="form-group">
//             <label htmlFor="password">Password:</label>
//             <input
//               type="password"
//               id="password"
//               className="input-field"
//               value={password}
//               onChange={(e) => setPassword(e.target.value)}
//               required
//             />
//           </div>
//           <button type="submit" className="login-button">
//             Login
//           </button>
//           <span className="no-account">Have no account?</span>
//           <button
//             type="button"
//             className="register-button"
//             onClick={handleRegister}
//           >
//             Register
//           </button>
//         </form>
//       )}
//     </>
//   );
// }

// export default LoginPage;
/////////////////////////////////////////////////////////////////
// // add a button named as Logout in the bottom of the left-slidebar, and add a functionality to this logout
// // button that when i press it it goes to a page named

// import React, { useState } from "react";
// import RegistrationForm from "./RegistrationForm"; // Assuming RegistrationForm.js is in the same directory
// import "./Login.css";

// function LoginPage() {
//   const [username, setUsername] = useState("");
//   const [password, setPassword] = useState("");
//   const [loggedIn, setLoggedIn] = useState(false);
//   const [showRegistration, setShowRegistration] = useState(false);

//   const handleSubmit = (e) => {
//     e.preventDefault();
//     setLoggedIn(true);
//   };

//   const handleLogout = () => {
//     setLoggedIn(false);
//     setUsername("");
//     setPassword("");
//   };

//   const handleRegister = () => {
//     setShowRegistration(true); // Show the registration form
//   };

//   if (loggedIn) {
//     return (
//       <div className="login-container">
//         <h2>Welcome, {username}!</h2>
//         <button className="logout-button" onClick={handleLogout}>
//           Logout
//         </button>
//       </div>
//     );
//   }

//   if (showRegistration) {
//     return <RegistrationForm />;
//   }

//   return (
//     <form className="login-container" onSubmit={handleSubmit}>
//       <h2>Login</h2>
//       <div className="form-group">
//         <label htmlFor="username">Username:</label>
//         <input
//           type="text"
//           id="username"
//           className="input-field"
//           value={username}
//           onChange={(e) => setUsername(e.target.value)}
//           required
//         />
//       </div>
//       <div className="form-group">
//         <label htmlFor="password">Password:</label>
//         <input
//           type="password"
//           id="password"
//           className="input-field"
//           value={password}
//           onChange={(e) => setPassword(e.target.value)}
//           required
//         />
//       </div>
//       <button type="submit" className="login-button">
//         Login
//       </button>
//       <span className="no-account">Have no account?</span>
//       <button
//         type="button"
//         className="register-button"
//         onClick={handleRegister}
//       >
//         Register
//       </button>
//     </form>
//   );
// }

// export default LoginPage;
